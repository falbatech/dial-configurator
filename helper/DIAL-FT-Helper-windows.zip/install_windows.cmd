@echo off
rem DIAL FT Helper - instalacja na Windows 10/11 (autostart po zalogowaniu). Odinstalowanie: uninstall_windows.cmd
setlocal
set "DEST=%LOCALAPPDATA%\FalbaTech\DIAL FT"
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0dialft_helper.ps1" "%DEST%\dialft_helper.ps1" >nul
rem zatrzymaj poprzednia wersje, jesli dziala
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*dialft_helper.ps1*' } | ForEach-Object { Invoke-CimMethod -InputObject $_ -MethodName Terminate | Out-Null }"
rem skrot w Autostarcie: ukryte okno PowerShell
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\DIAL FT Helper.lnk'); $s.TargetPath='powershell.exe'; $s.Arguments='-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"%DEST%\dialft_helper.ps1\"'; $s.WindowStyle=7; $s.Description='DIAL FT Helper'; $s.Save()"
start "" powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%DEST%\dialft_helper.ps1"
echo.
echo DIAL FT Helper zainstalowany i uruchomiony. Bedzie startowal sam po zalogowaniu.
echo DIAL FT Helper installed and running. It will start automatically at login.
echo.
pause
