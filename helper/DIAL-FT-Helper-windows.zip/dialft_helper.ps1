# DIAL FT Helper (Windows) - automatyczny profil, zegar i Spotify Now Playing dla DIAL FT.
# Windows PowerShell 5.1 (wbudowany w Windows 10/11), bez instalowania czegokolwiek.
#   - APP <nazwa.exe>   po zmianie programu na wierzchu (DIAL przelacza profil)
#   - TIME <epoch> <strefa_min>   co 10 minut (tarcza zegarka, statystyki Pomodoro)
#   - NP META / NP OFF / NP ART...   Spotify: tytul, wykonawca, postep, okladka (systemowe API odtwarzaczy, GSMTC)
# Uruchomienie: powershell -ExecutionPolicy Bypass -File dialft_helper.ps1   (autostart: install_windows.cmd)

$ErrorActionPreference = 'SilentlyContinue'
$Version = '1.0'
$ArtW = 112; $ArtH = 112; $Chunk = 192

# jedna kopia naraz
$mutex = New-Object System.Threading.Mutex($false, 'Global\FalbaTechDialFtHelper')
if (-not $mutex.WaitOne(0)) { exit }

function Log($m) { Write-Host ("{0} [DIAL FT] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m) }

# ---------------------------------------------------------------- program na wierzchu
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class DialFtWin {
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  public static uint ForegroundPid() { uint pid; GetWindowThreadProcessId(GetForegroundWindow(), out pid); return pid; }
}
'@

# ---------------------------------------------------------------- dzwiek i powiadomienie (EVT z DIAL)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$script:Pl = (Get-Culture).TwoLetterISOLanguageName -eq 'pl'
# zdarzenie: tekst PL, tekst EN, dzwiek z C:\Windows\Media, ile razy zagrac
$script:Alerts = @{
  'POMO BREAK' = @('Koniec skupienia - czas na przerwe', 'Focus done - time for a break', 'Windows Notify Calendar.wav', 1)
  'POMO FOCUS' = @('Koniec przerwy - wracamy do pracy', 'Break over - back to work', 'Windows Notify Calendar.wav', 1)
  'TIMER'      = @('Czas minal', "Time's up", 'Alarm01.wav', 1)
  'STANDUP'    = @('Pora wstac i sie rozruszac', 'Time to stand up and stretch', 'Windows Notify System Generic.wav', 1)
}
$script:Tray = $null
function Pc-Alert($ev) {
  $a = $script:Alerts[$ev]
  if (-not $a) { return }
  $text = if ($script:Pl) { $a[0] } else { $a[1] }
  $wav = Join-Path $env:WINDIR ('Media\' + $a[2])
  try {
    if (Test-Path $wav) { (New-Object System.Media.SoundPlayer $wav).Play() } else { [System.Media.SystemSounds]::Exclamation.Play() }
  } catch {}
  try {
    if (-not $script:Tray) {
      $script:Tray = New-Object System.Windows.Forms.NotifyIcon
      $script:Tray.Icon = [System.Drawing.SystemIcons]::Information
      $script:Tray.Text = 'DIAL FT Helper'
    }
    $script:Tray.Visible = $true
    $script:Tray.ShowBalloonTip(6000, 'DIAL FT', $text, [System.Windows.Forms.ToolTipIcon]::Info)
  } catch {}
  Log ("powiadomienie: " + $text)
}

function Get-FrontExe {
  $procId = [DialFtWin]::ForegroundPid()
  if (-not $procId) { return '' }
  $p = Get-Process -Id $procId
  if (-not $p) { return '' }
  return ($p.ProcessName + '.exe')
}

# ---------------------------------------------------------------- port DIAL FT (USB VID 303A)
function Find-Dial {
  $ports = Get-CimInstance Win32_PnPEntity | Where-Object { $_.DeviceID -like 'USB\VID_303A*' -and $_.Name -match '\((COM\d+)\)' } |
           ForEach-Object { if ($_.Name -match '\((COM\d+)\)') { $Matches[1] } }
  foreach ($name in $ports) {
    $sp = New-Object System.IO.Ports.SerialPort($name, 115200)
    $sp.DtrEnable = $true; $sp.ReadTimeout = 50; $sp.WriteTimeout = 1000; $sp.NewLine = "`n"
    try {
      $sp.Open()
      $sp.Write("HELLO`n")
      $t0 = Get-Date; $buf = ''
      while (((Get-Date) - $t0).TotalMilliseconds -lt 1000) {
        $buf += $sp.ReadExisting()
        if ($buf -match 'DIAL FT') { return $sp }
        Start-Sleep -Milliseconds 30
      }
      $sp.Close()
    } catch { try { $sp.Close() } catch {} }
  }
  return $null
}

# ---------------------------------------------------------------- czas
function Get-TimeLine {
  $now = [DateTimeOffset]::Now
  return ('TIME {0} {1}' -f $now.ToUnixTimeSeconds(), [int]$now.Offset.TotalMinutes)
}

# ---------------------------------------------------------------- Spotify przez GSMTC (WinRT)
$GsmtcOk = $false
try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  Add-Type -AssemblyName System.Drawing
  $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
      $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
  function Await($op, [Type]$t) {
    $task = $asTaskGeneric.MakeGenericMethod($t).Invoke($null, @($op))
    $null = $task.Wait(3000)
    return $task.Result
  }
  [void][Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
  [void][Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $Mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
  if ($Mgr) { $GsmtcOk = $true }
} catch { $GsmtcOk = $false }

function To-Ascii([string]$s, [int]$n = 40) {
  if (-not $s) { return '' }
  $s = $s.Replace([string][char]0x142, 'l').Replace([string][char]0x141, 'L').Replace("`t", ' ')
  $d = $s.Normalize([Text.NormalizationForm]::FormD)
  $sb = New-Object Text.StringBuilder
  foreach ($c in $d.ToCharArray()) {
    if ([Globalization.CharUnicodeInfo]::GetUnicodeCategory($c) -ne [Globalization.UnicodeCategory]::NonSpacingMark -and [int]$c -lt 128) { [void]$sb.Append($c) }
  }
  $r = $sb.ToString()
  if ($r.Length -gt $n) { $r = $r.Substring(0, $n) }
  return $r
}

function Get-SpotifySession {
  if (-not $GsmtcOk) { return $null }
  foreach ($s in $Mgr.GetSessions()) { if ($s.SourceAppUserModelId -match 'Spotify') { return $s } }
  return $null
}

$script:ArtCache = @{ Id = ''; Data = $null }
function Get-NowPlaying {
  $s = Get-SpotifySession
  if (-not $s) { return $null }
  $props = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
  if (-not $props) { return $null }
  $tl = $s.GetTimelineProperties()
  $playing = ($s.GetPlaybackInfo().PlaybackStatus -eq 'Playing')
  $pos = $tl.Position.TotalSeconds
  if ($playing -and $tl.LastUpdatedTime) { $pos += ([DateTimeOffset]::Now - $tl.LastUpdatedTime).TotalSeconds }
  $dur = $tl.EndTime.TotalSeconds
  if ($dur -gt 0 -and $pos -gt $dur) { $pos = $dur }
  $idSrc = "$($props.Title)|$($props.Artist)"
  $md5 = [Security.Cryptography.MD5]::Create()
  $id = ([BitConverter]::ToString($md5.ComputeHash([Text.Encoding]::UTF8.GetBytes($idSrc))) -replace '-', '').Substring(0, 16).ToLower()
  return @{ Playing = $playing; Pos = [int]$pos; Dur = [int]$dur; Id = $id; Title = (To-Ascii $props.Title); Artist = (To-Ascii $props.Artist); Props = $props }
}

function Get-ArtRgb565($np) {   # okladka 112x112 -> RGB565 little endian
  if ($script:ArtCache.Id -eq $np.Id -and $script:ArtCache.Data) { return $script:ArtCache.Data }
  try {
    $ref = $np.Props.Thumbnail
    if (-not $ref) { return $null }
    $ras = Await ($ref.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
    $stream = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($ras)
    $img = [System.Drawing.Image]::FromStream($stream)
    $bmp = New-Object System.Drawing.Bitmap($ArtW, $ArtH, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    # kwadratowy srodek (Spotify na Windows potrafi dac miniature z paskami)
    $side = [Math]::Min($img.Width, $img.Height)
    $src = New-Object System.Drawing.Rectangle([int](($img.Width - $side) / 2), [int](($img.Height - $side) / 2), $side, $side)
    $g.DrawImage($img, (New-Object System.Drawing.Rectangle(0, 0, $ArtW, $ArtH)), $src, [System.Drawing.GraphicsUnit]::Pixel)
    $g.Dispose(); $img.Dispose(); $stream.Dispose()
    $rect = New-Object System.Drawing.Rectangle(0, 0, $ArtW, $ArtH)
    $bd = $bmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $raw = New-Object byte[] ($bd.Stride * $ArtH)
    [System.Runtime.InteropServices.Marshal]::Copy($bd.Scan0, $raw, 0, $raw.Length)
    $bmp.UnlockBits($bd); $bmp.Dispose()
    $out = New-Object byte[] ($ArtW * $ArtH * 2)
    $o = 0
    for ($y = 0; $y -lt $ArtH; $y++) {
      $row = $y * $bd.Stride
      for ($x = 0; $x -lt $ArtW; $x++) {
        $i = $row + $x * 3
        $b = $raw[$i]; $gg = $raw[$i + 1]; $r = $raw[$i + 2]
        $v = (($r -band 0xF8) -shl 8) -bor (($gg -band 0xFC) -shl 3) -bor ($b -shr 3)
        $out[$o] = [byte]($v -band 0xFF); $out[$o + 1] = [byte]($v -shr 8); $o += 2
      }
    }
    $script:ArtCache = @{ Id = $np.Id; Data = $out }
    return $out
  } catch { Log "okladka: $_"; return $null }
}

# ---------------------------------------------------------------- petla glowna
Log "DIAL FT Helper (Windows) $Version"
$sp = $null; $buf = ''
$lastSearch = [DateTime]::MinValue; $lastTime = [DateTime]::MinValue; $lastFront = [DateTime]::MinValue; $lastNp = [DateTime]::MinValue
$front = ''; $sentOff = $false; $np = $null

function Send($line) {
  if (-not $script:sp) { return }
  try { $script:sp.Write($line + "`n") } catch { Log 'DIAL FT odlaczony'; try { $script:sp.Close() } catch {}; $script:sp = $null }
}

function Send-Art($trackId) {
  if (-not $script:np -or $script:np.Id -ne $trackId) { return }
  $data = Get-ArtRgb565 $script:np
  if (-not $data) { return }
  $n = [Math]::Ceiling($data.Length / $Chunk)
  Send ("NP ART {0} {1} {2} {3}" -f $trackId, $ArtW, $ArtH, $n)
  for ($i = 0; $i -lt $n; $i++) {
    $len = [Math]::Min($Chunk, $data.Length - $i * $Chunk)
    Send ("NP A {0} {1}" -f $i, [Convert]::ToBase64String($data, $i * $Chunk, $len))
    if ($i % 8 -eq 7) { Start-Sleep -Milliseconds 4 }
  }
  Send ("NP END {0}" -f $trackId)
}

while ($true) {
  $now = Get-Date
  if (-not $sp -and ($now - $lastSearch).TotalSeconds -gt 2) {
    $lastSearch = $now
    $sp = Find-Dial
    if ($sp) { Log "polaczono z DIAL FT: $($sp.PortName)"; $buf = ''; $lastTime = [DateTime]::MinValue; $front = ''; $sentOff = $false }
  }
  if ($sp) {
    try { $buf += $sp.ReadExisting() } catch { Log 'DIAL FT odlaczony'; try { $sp.Close() } catch {}; $sp = $null }
    while ($buf.Contains("`n")) {
      $k = $buf.IndexOf("`n"); $line = $buf.Substring(0, $k).Trim(); $buf = $buf.Substring($k + 1)
      if ($line.StartsWith('NP NEED ')) { Send-Art $line.Substring(8).Trim() }
      elseif ($line.StartsWith('EVT ')) { Pc-Alert $line.Substring(4).Trim() }
    }
    if (($now - $lastTime).TotalSeconds -gt 600) { $lastTime = $now; Send (Get-TimeLine) }
    if (($now - $lastFront).TotalMilliseconds -gt 800) {
      $lastFront = $now
      $f = Get-FrontExe
      if ($f -and $f -ne $front) { $front = $f; Send ("APP " + $f) }
    }
    if (($now - $lastNp).TotalSeconds -ge 1) {
      $lastNp = $now
      $np = Get-NowPlaying
      if (-not $np) {
        if (-not $sentOff) { Send 'NP OFF'; $sentOff = $true }
      } else {
        $sentOff = $false
        Send ("NP META {0} {1} {2} {3}`t{4}`t{5}" -f ([int]$np.Playing), $np.Pos, $np.Dur, $np.Id, $np.Title, $np.Artist)
      }
    }
  }
  Start-Sleep -Milliseconds 50
}
