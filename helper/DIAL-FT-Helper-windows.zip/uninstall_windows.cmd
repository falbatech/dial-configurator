@echo off
rem DIAL FT Helper - odinstalowanie na Windows
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*dialft_helper.ps1*' } | ForEach-Object { Invoke-CimMethod -InputObject $_ -MethodName Terminate | Out-Null }"
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\DIAL FT Helper.lnk" 2>nul
rmdir /S /Q "%LOCALAPPDATA%\FalbaTech\DIAL FT" 2>nul
echo DIAL FT Helper odinstalowany. / uninstalled.
pause
