# DIAL FT Helper (Windows 10/11)

Opcjonalny program w tle. Dodaje:
- **automatyczny profil**: DIAL sam przelacza profil, gdy przechodzisz do programu (DaVinci, Premiere, Photoshop, Lightroom,
  Spotify, Zoom, Teams, Figma, Blender, Fusion 360, KiCad oraz Twoje profile z polem "Program", np. `chrome.exe`);
- **zegar** dla tarczy zegarka i statystyk Pomodoro;
- **Spotify**: tytul, wykonawca, postep i okladka na ekranie DIAL (systemowe sterowanie multimediami Windows).

Nic nie trzeba instalowac - dziala na wbudowanym Windows PowerShell.

## Instalacja
1. Rozpakuj archiwum.
2. Kliknij dwa razy `install_windows.cmd`. Jesli Windows pokaze "System Windows ochronil ten komputer", kliknij
   "Wiecej informacji" -> "Uruchom mimo to" (plik pochodzi z internetu i nie jest podpisany).
3. Helper startuje od razu i sam po kazdym zalogowaniu.

Odinstalowanie: `uninstall_windows.cmd`.
Recznie (podglad komunikatow): `powershell -ExecutionPolicy Bypass -File dialft_helper.ps1`
