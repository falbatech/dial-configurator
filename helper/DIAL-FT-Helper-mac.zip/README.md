# DIAL FT Helper (macOS)

Opcjonalny program w tle (macOS) - wersje na Windows i Linux sa w folderach `windows/` i `linux/`. Pokazuje na DIAL FT, co gra w aplikacji **Spotify** (tytul, wykonawca, okladka, postep utworu, pauza), wlacza automatyczny profil i ustawia zegar.
Reszta DIAL FT (wszystkie profile, takze COLOR w DaVinci) dziala bez niego.

Czyta dane z wlaczonej aplikacji Spotify przez AppleScript - bez logowania i bez API Spotify w internecie.
Okladka jest pobierana z adresu podanego przez Spotify i skalowana systemowym `sips` do 112x112.
Tylko biblioteka standardowa Pythona (`/usr/bin/python3` z macOS).

## Instalacja (start przy logowaniu)
```
tools/helper/install_mac.sh
```
Przy pierwszym utworze macOS zapyta o zgode na sterowanie Spotify (Ustawienia > Prywatnosc > Automatyzacja).
Odinstalowanie: `tools/helper/install_mac.sh --uninstall`. Recznie: `python3 tools/helper/dialft_helper.py`.

## Na DIAL
Profil Spotify: okladka, tytul, wykonawca, obrzeze ekranu = postep utworu, dwie belki = pauza.
Bez helpera profil dziala dalej (klawisze multimedialne), tylko bez okladki.

## Protokol
Helper -> DIAL: `NP META <grane 0/1> <poz_s> <dl_s> <id>\t<tytul>\t<wykonawca>`, `NP OFF`,
okladka na zadanie: `NP ART <id> 112 112 <n>`, `NP A <nr> <base64 192 B>`, `NP END <id>` (RGB565 LE).
DIAL -> helper: `NP NEED <id>`.

Windows: jeszcze nie (Spotify nie ma tam AppleScript; potrzebne systemowe API "Media Transport Controls").

## Claude Code (wszystkie systemy)
Helper nasluchuje na `http://127.0.0.1:47812/claude/<busy|ask|done|idle>` (POST z hookow typu `http` w `~/.claude/settings.json`:
UserPromptSubmit -> busy, Notification -> ask, Stop -> done) i wysyla do DIAL `CLAUDE <STAN>`; odpowiada 200 bez tresci.
Instalatory pytaja o dodanie hookow; recznie: `dialft_helper.py --install-claude-hooks` / `--remove-claude-hooks`,
Windows: `dialft_helper.ps1 -InstallClaudeHooks` / `-RemoveClaudeHooks` (kopia: settings.json.dialft-backup).
DIAL odsyla `EVT CLAUDE ASK` / `EVT CLAUDE DONE` -> dzwiek i powiadomienie (ustawienie „Dzwiek na komputerze”).

## Codex (OpenAI Codex CLI)
Codex ma tylko hooki typu `command` (`~/.codex/hooks.json`): UserPromptSubmit -> busy, PermissionRequest -> ask, Stop -> done.
Hook wywoluje `dialft_helper.py --notify codex <stan>` (Windows: `dialft_helper.ps1 -Notify codex/<stan>`), ktore wysyla
POST na `http://127.0.0.1:47812/codex/<stan>`; Helper -> DIAL: `CODEX <STAN>`. Instalacja: `--install-codex-hooks` /
`-InstallCodexHooks`, potem w Codex `/hooks` i zatwierdzenie (Codex uruchamia tylko zatwierdzone hooki).

## herdr (macOS, Linux)
Helper co 1,5 s pyta socket herdr (`$HERDR_SOCKET_PATH` albo `~/.config/herdr/herdr.sock`, JSON w jednym wierszu:
`{"id":"dialft","method":"pane.list","params":{}}`), liczy wszystkie pola `agent_status` i wysyla do DIAL
`HERDR <working> <blocked> <done> <idle>` przy kazdej zmianie, `HERDR OFF` gdy herdr przestanie dzialac.
Windows: herdr uzywa tam nazwanego potoku bez udokumentowanej nazwy - na razie bez obslugi.
