#!/usr/bin/env python3
"""DIAL FT Helper (macOS) - Now Playing ze Spotify, automatyczny profil i zegar dla DIAL FT.

Wysyla tez: "APP <bundle id>" po zmianie aplikacji na wierzchu (DIAL przelacza profil) i "TIME <epoch> <strefa_min>".

Co sekunde pyta Spotify (AppleScript) o utwor, wykonawce, pozycje i okladke, wysyla na DIAL:
    NP META <stan 0/1> <pozycja_s> <dlugosc_s> <id>\t<tytul>\t<wykonawca>
    NP OFF                                   (Spotify nie dziala)
Okladka 112x112 RGB565 tylko na zadanie DIAL ("NP NEED <id>"):
    NP ART <id> <w> <h> <liczba_kawalkow>, NP A <nr> <base64>, NP END <id>
Koniec Pomodoro / Timera / przypomnienie o przerwie: DIAL wysyla "EVT <zdarzenie>", helper gra dzwiek i pokazuje powiadomienie.
Port 127.0.0.1:47811: przekaznik wierszy do DIAL (dla wlasnych narzedzi; "STATUS" zwraca stan DIAL).

Tylko biblioteka standardowa + narzedzia systemu (osascript, sips).
Uruchomienie: python3 dialft_helper.py   (instalacja w tle: install_mac.sh)
Pierwsze uruchomienie: macOS zapyta o zgode na sterowanie aplikacja Spotify - zezwol.
"""
import base64
import glob
import os
import select
import socket
import subprocess
import sys
import tempfile
import time
import unicodedata
import urllib.request

VERSION = "1.5"
RELAY_PORT = 47811
ART_W = ART_H = 112
CHUNK = 192
SEP = "\x1f"

APPLESCRIPT = '''
if application "Spotify" is running then
  tell application "Spotify"
    set s to (ASCII character 31)
    try
      set t to current track
      return (player state as text) & s & ((player position * 1000) as integer) & s & (duration of t) & s & (id of t) & s & (name of t) & s & (artist of t) & s & (artwork url of t)
    on error
      return "stopped"
    end try
  end tell
else
  return "off"
end if
'''


# ---------------------------------------------------------------- dzwiek i powiadomienie (EVT z DIAL)
# zdarzenie: (tekst PL, tekst EN, dzwiek systemowy, ile razy zagrac)
ALERTS = {
    "POMO BREAK": ("Koniec skupienia - czas na przerwę", "Focus done - time for a break", "Glass", 1),
    "POMO FOCUS": ("Koniec przerwy - wracamy do pracy", "Break over - back to work", "Hero", 1),
    "TIMER": ("Czas minął", "Time's up", "Ping", 3),
    "STANDUP": ("Pora wstać i się rozruszać", "Time to stand up and stretch", "Submarine", 1),    "CLAUDE ASK": ("Claude czeka na Ciebie", "Claude needs your input", "Funk", 1),
    "CLAUDE DONE": ("Claude skończył", "Claude is done", "Glass", 1),    "CODEX ASK": ("Codex czeka na Ciebie", "Codex needs your input", "Funk", 1),
    "CODEX DONE": ("Codex skończył", "Codex is done", "Glass", 1),
}


def system_pl():
    try:
        return subprocess.run(["defaults", "read", "-g", "AppleLocale"], capture_output=True, text=True, timeout=2).stdout.startswith("pl")
    except Exception:
        return False


LANG_PL = system_pl()


def pc_alert(ev):
    a = ALERTS.get(ev)
    if not a:
        return
    text = a[0] if LANG_PL else a[1]
    snd = "/System/Library/Sounds/%s.aiff" % a[2]
    # w tle: helper nie czeka na koniec dzwieku
    subprocess.Popen(["/bin/sh", "-c", 'for i in $(seq %d); do afplay "%s"; done' % (a[3], snd)],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.Popen(["osascript", "-e", 'display notification "%s" with title "DIAL FT"' % text.replace('"', "'")],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    log("powiadomienie:", text)


# ---------------------------------------------------------------- Claude Code (hooki http -> DIAL)
# Claude Code wysyla POST na http://127.0.0.1:47812/claude/<busy|ask|done|idle> (hooki typu "http" w ~/.claude/settings.json).
# Helper przekazuje "CLAUDE <STAN>" do DIAL i od razu odpowiada 200 bez tresci (Claude Code nic nie dostaje do kontekstu).
CLAUDE_PORT = 47812
CLAUDE_STATES = {"busy": "BUSY", "ask": "ASK", "done": "DONE", "idle": "IDLE"}
AI_AGENTS = ("claude", "codex")   # sciezka /<agent>/<stan> -> wiersz "<AGENT> <STAN>" do DIAL
CLAUDE_HOOKS = {"UserPromptSubmit": "busy", "Notification": "ask", "Stop": "done"}


def claude_server():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind(("127.0.0.1", CLAUDE_PORT))
    except OSError:
        log("port %d zajety - powiadomienia Claude Code wylaczone" % CLAUDE_PORT)
        return None
    s.listen(8)
    s.setblocking(False)
    return s


def claude_request(data):
    """Zwraca "AGENT STAN" z kompletnego zapytania HTTP albo None, gdy jeszcze nie doszlo w calosci ("" = obce)."""
    head, sep, body = data.partition(b"\r\n\r\n")
    if not sep:
        return None if len(data) < 16384 else ""
    length = 0
    for ln in head.split(b"\r\n")[1:]:
        k, _, v = ln.partition(b":")
        if k.strip().lower() == b"content-length":
            try:
                length = int(v.strip())
            except ValueError:
                pass
    if len(body) < min(length, 65536):
        return None
    parts = head.split(b"\r\n", 1)[0].decode(errors="ignore").split()
    path = parts[1] if len(parts) > 1 else ""
    seg = path.strip("/").split("/")
    if len(seg) != 2 or seg[0] not in AI_AGENTS or seg[1] not in CLAUDE_STATES:
        return ""
    return seg[0].upper() + " " + CLAUDE_STATES[seg[1]]


def claude_reply(c):
    try:
        c.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
    except OSError:
        pass
    c.close()


def claude_hooks(install):
    """Dodaje (albo usuwa) hooki DIAL FT w ~/.claude/settings.json; inne ustawienia i hooki zostaja."""
    import json
    path = os.path.expanduser("~/.claude/settings.json")
    try:
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
    except FileNotFoundError:
        cfg = {}
    except ValueError:
        sys.exit("Nie moge odczytac %s (bledny JSON) - nic nie zmieniono." % path)
    hooks = cfg.setdefault("hooks", {})
    mine = lambda h: str(h.get("url", "")).startswith("http://127.0.0.1:%d/claude/" % CLAUDE_PORT)
    for ev, st in CLAUDE_HOOKS.items():
        groups = [g for g in hooks.get(ev, []) if not any(mine(h) for h in g.get("hooks", []))]
        if install:
            groups.append({"hooks": [{"type": "http", "url": "http://127.0.0.1:%d/claude/%s" % (CLAUDE_PORT, st), "timeout": 3}]})
        if groups:
            hooks[ev] = groups
        else:
            hooks.pop(ev, None)
    if not hooks:
        cfg.pop("hooks")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f, open(path + ".dialft-backup", "w", encoding="utf-8") as b:
            b.write(f.read())
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print(("Dodano" if install else "Usunieto") + " powiadomienia DIAL FT w " + path)


CODEX_HOOKS = {"UserPromptSubmit": "busy", "PermissionRequest": "ask", "Stop": "done"}


def notify(agent, state):
    """Wywolywane przez hooki (np. Codex): przekazuje stan do dzialajacego Helpera; zawsze konczy sie po cichu."""
    try:
        sys.stdin.read() if not sys.stdin.isatty() else None   # hook podaje JSON na stdin - odczytujemy, zeby nie blokowac
    except Exception:
        pass
    try:
        c = socket.create_connection(("127.0.0.1", CLAUDE_PORT), 1)
        c.sendall(("POST /%s/%s HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Length: 0\r\nConnection: close\r\n\r\n" % (agent, state)).encode())
        c.settimeout(1)
        c.recv(64)
        c.close()
    except OSError:
        pass


def codex_hooks(install):
    """Dodaje (albo usuwa) hooki DIAL FT w ~/.codex/hooks.json; inne hooki zostaja."""
    import json
    path = os.path.expanduser("~/.codex/hooks.json")
    try:
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
    except FileNotFoundError:
        cfg = {}
    except ValueError:
        sys.exit("Nie moge odczytac %s (bledny JSON) - nic nie zmieniono." % path)
    hooks = cfg.setdefault("hooks", {})
    mine = lambda h: "dialft_helper" in str(h.get("command", "")) and "--notify codex" in str(h.get("command", ""))
    me = os.path.abspath(__file__)
    for ev, st in CODEX_HOOKS.items():
        groups = [g for g in hooks.get(ev, []) if not any(mine(h) for h in g.get("hooks", []))]
        if install:
            groups.append({"hooks": [{"type": "command", "command": '"%s" "%s" --notify codex %s' % (sys.executable, me, st), "timeout": 5}]})
        if groups:
            hooks[ev] = groups
        else:
            hooks.pop(ev, None)
    if not hooks:
        cfg.pop("hooks")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f, open(path + ".dialft-backup", "w", encoding="utf-8") as b:
            b.write(f.read())
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print(("Dodano" if install else "Usunieto") + " powiadomienia DIAL FT w " + path)
    if install:
        print("W Codex wpisz /hooks i zatwierdz nowe hooki (Codex uruchamia tylko zatwierdzone).")


def log(*a):
    print(time.strftime("%H:%M:%S"), "[DIAL FT]", *a, flush=True)


# ---------------------------------------------------------------- serial
class PosixSerial:
    def __init__(self, path):
        import termios
        import tty
        self.fd = os.open(path, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        tty.setraw(self.fd)
        attrs = termios.tcgetattr(self.fd)
        attrs[4] = attrs[5] = termios.B115200
        termios.tcsetattr(self.fd, termios.TCSANOW, attrs)
        self.name = path

    def read(self, n=4096):
        try:
            return os.read(self.fd, n)
        except BlockingIOError:
            return b""

    def write(self, data):
        view = memoryview(data)
        t0 = time.time()
        while view:
            try:
                k = os.write(self.fd, view)
                view = view[k:]
            except BlockingIOError:
                if time.time() - t0 > 2.0:
                    raise OSError("write timeout")
                time.sleep(0.002)

    def close(self):
        try:
            os.close(self.fd)
        except OSError:
            pass


def find_dial():
    for path in sorted(glob.glob("/dev/cu.usbmodem*")):
        try:
            s = PosixSerial(path)
        except OSError:
            continue
        try:
            s.write(b"HELLO\n")
            t0, buf = time.time(), b""
            while time.time() - t0 < 1.0:
                buf += s.read()
                if b"DIAL FT" in buf:
                    return s
                time.sleep(0.02)
        except OSError:
            pass
        s.close()
    return None


# ---------------------------------------------------------------- Spotify
def ascii_text(s, n=40):
    """Font DIAL nie ma polskich znakow: transliteracja do ASCII."""
    s = s.replace("ł", "l").replace("Ł", "L").replace("\t", " ")
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return s[:n]


def spotify_now():
    try:
        out = subprocess.run(["osascript", "-e", APPLESCRIPT], capture_output=True, text=True, timeout=3).stdout.strip()
    except Exception:
        return None
    if out in ("off", ""):
        return None
    if out == "stopped":
        return {"playing": False, "pos": 0, "dur": 0, "id": "", "title": "", "artist": "", "art": ""}
    p = out.split(SEP)
    if len(p) < 7:
        return None
    try:
        return {"playing": p[0] == "playing", "pos": int(p[1]) // 1000, "dur": int(p[2]) // 1000,
                "id": p[3].split(":")[-1][:22], "title": ascii_text(p[4]), "artist": ascii_text(p[5]), "art": p[6]}
    except ValueError:
        return None


_art_cache = {}


def artwork_rgb565(url):
    """Pobiera okladke, skaluje sips-em do 112x112 BMP i zamienia na RGB565 (little endian)."""
    if url in _art_cache:
        return _art_cache[url]
    tmp = tempfile.mkdtemp(prefix="dialft_")
    jpg, bmp = os.path.join(tmp, "a.jpg"), os.path.join(tmp, "a.bmp")
    try:
        with urllib.request.urlopen(url, timeout=5) as r, open(jpg, "wb") as f:
            f.write(r.read())
        subprocess.run(["sips", "-s", "format", "bmp", "-z", str(ART_H), str(ART_W), jpg, "--out", bmp],
                       capture_output=True, timeout=10, check=True)
        d = open(bmp, "rb").read()
        off = int.from_bytes(d[10:14], "little")
        w = int.from_bytes(d[18:22], "little", signed=True)
        h = int.from_bytes(d[22:26], "little", signed=True)
        bpp = int.from_bytes(d[28:30], "little")
        if w != ART_W or abs(h) != ART_H or bpp not in (24, 32):
            raise ValueError("bmp %dx%d %d" % (w, h, bpp))
        bpx = bpp // 8
        stride = (w * bpx + 3) & ~3
        out = bytearray(w * abs(h) * 2)
        o = 0
        for y in range(abs(h)):
            row = off + (y if h < 0 else abs(h) - 1 - y) * stride
            for x in range(w):
                b, g, r = d[row + x * bpx], d[row + x * bpx + 1], d[row + x * bpx + 2]
                v = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)
                out[o] = v & 0xFF
                out[o + 1] = v >> 8
                o += 2
        _art_cache.clear()
        _art_cache[url] = bytes(out)
        return _art_cache[url]
    except Exception as e:
        log("okladka:", e)
        return None
    finally:
        for f in (jpg, bmp):
            try:
                os.remove(f)
            except OSError:
                pass
        try:
            os.rmdir(tmp)
        except OSError:
            pass


# ---------------------------------------------------------------- aktywna aplikacja / czas
def front_bundle():
    """Identyfikator aplikacji na wierzchu (bundle id), przez systemowe lsappinfo."""
    try:
        asn = subprocess.run(["lsappinfo", "front"], capture_output=True, text=True, timeout=1).stdout.strip()
        out = subprocess.run(["lsappinfo", "info", "-only", "bundleid", asn], capture_output=True, text=True, timeout=1).stdout
        return out.split("=")[-1].strip().strip('"')
    except Exception:
        return ""


def time_line():
    now = time.time()
    tz_min = int(round(time.localtime(now).tm_gmtoff / 60))   # z czasem letnim (CEST = +120, CET = +60)
    return "TIME %d %d" % (int(now), tz_min)


# ---------------------------------------------------------------- main
def main():
    log("DIAL FT Helper %s" % VERSION)
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        srv.bind(("127.0.0.1", RELAY_PORT))
    except OSError:
        sys.exit("Helper juz dziala (port %d zajety)." % RELAY_PORT)
    srv.listen(4)
    srv.setblocking(False)
    clients = {}           # socket -> bufor
    csrv = claude_server()
    cclients = {}          # Claude Code: socket -> bufor zapytania HTTP
    ser, buf = None, b""
    last_search = last_np = 0.0
    now_playing = None
    sent_off = False
    last_time = last_front = 0.0
    front = ""

    def to_dial(line):
        nonlocal ser
        if ser is None:
            return
        try:
            ser.write((line + "\n").encode())
        except OSError:
            log("DIAL FT odlaczony")
            ser.close()
            ser = None

    def to_clients(line):
        for c in list(clients):
            try:
                c.sendall((line + "\n").encode())
            except OSError:
                c.close()
                clients.pop(c, None)

    def send_art(track_id):
        if not now_playing or now_playing["id"] != track_id or not now_playing["art"]:
            return
        data = artwork_rgb565(now_playing["art"])
        if not data:
            return
        n = (len(data) + CHUNK - 1) // CHUNK
        to_dial("NP ART %s %d %d %d" % (track_id, ART_W, ART_H, n))
        for i in range(n):
            to_dial("NP A %d %s" % (i, base64.b64encode(data[i * CHUNK:(i + 1) * CHUNK]).decode()))
            if i % 8 == 7:
                time.sleep(0.004)   # tempo: bufor odbiorczy DIAL ma 8 kB
        to_dial("NP END %s" % track_id)

    while True:
        now = time.time()
        if ser is None and now - last_search > 2.0:
            last_search = now
            ser = find_dial()
            if ser:
                buf = b""
                sent_off = False
                last_time = 0.0
                front = ""
                log("polaczono z DIAL FT:", ser.name)

        rlist = [srv] + list(clients) + ([ser.fd] if ser else []) + ([csrv] if csrv else []) + list(cclients)
        try:
            ready, _, _ = select.select(rlist, [], [], 0.05)
        except (OSError, ValueError):
            ready = []
        for r in ready:
            if r is csrv:
                try:
                    c, _ = csrv.accept()
                    c.setblocking(False)
                    cclients[c] = b""
                except OSError:
                    pass
                continue
            if r in cclients:
                try:
                    data = r.recv(65536)
                except OSError:
                    data = b""
                cclients[r] += data
                st = claude_request(cclients[r])
                if st is None and data:
                    continue
                cclients.pop(r, None)
                claude_reply(r)
                if st:
                    to_dial(st)
                continue
            if r is srv:
                try:
                    c, _ = srv.accept()
                    c.setblocking(False)
                    clients[c] = b""
                except OSError:
                    pass
            elif ser and r == ser.fd:
                data = ser.read()
                if not data:
                    log("DIAL FT odlaczony")
                    ser.close()
                    ser = None
                    continue
                buf += data
            elif r in clients:
                try:
                    data = r.recv(4096)
                except OSError:
                    data = b""
                if not data:
                    r.close()
                    clients.pop(r, None)
                    continue
                clients[r] += data
                while b"\n" in clients[r]:
                    line, clients[r] = clients[r].split(b"\n", 1)
                    line = line.decode(errors="ignore").strip()
                    if line == "HELLO":
                        r.sendall(b"DIAL FT relay\n")
                    elif line == "STATUS":
                        to_dial(line)

        while b"\n" in buf:
            raw, buf = buf.split(b"\n", 1)
            line = raw.decode(errors="ignore").strip()
            if line.startswith("DIAL FT "):
                to_clients(line)
            elif line.startswith("NP NEED "):
                send_art(line[8:].strip())
            elif line.startswith("EVT "):
                pc_alert(line[4:].strip())

        if ser and now - last_time > 600:   # zegar DIAL (tarcza, statystyki Pomodoro)
            last_time = now
            to_dial(time_line())
        if ser and now - last_front > 0.8:   # automatyczny profil wg aplikacji na wierzchu
            last_front = now
            f = front_bundle()
            if f and f != front:
                front = f
                to_dial("APP " + f)

        if now - last_np > 1.0:
            last_np = now
            np_ = spotify_now()
            if np_ is None:
                now_playing = None
                if not sent_off:
                    to_dial("NP OFF")
                    sent_off = True
            else:
                sent_off = False
                now_playing = np_
                to_dial("NP META %d %d %d %s\t%s\t%s" % (np_["playing"], np_["pos"], np_["dur"], np_["id"] or "-",
                                                          np_["title"], np_["artist"]))


if __name__ == "__main__" and len(sys.argv) > 1 and sys.argv[1] in ("--install-claude-hooks", "--remove-claude-hooks"):
    claude_hooks(sys.argv[1] == "--install-claude-hooks")
    sys.exit(0)
if __name__ == "__main__" and len(sys.argv) > 1 and sys.argv[1] in ("--install-codex-hooks", "--remove-codex-hooks"):
    codex_hooks(sys.argv[1] == "--install-codex-hooks")
    sys.exit(0)
if __name__ == "__main__" and len(sys.argv) > 3 and sys.argv[1] == "--notify":   # hook: --notify <claude|codex> <busy|ask|done|idle>
    notify(sys.argv[2], sys.argv[3])
    sys.exit(0)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
