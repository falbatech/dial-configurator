# DIAL FT Helper (Linux)

Opcjonalny program w tle (Python 3, bez dodatkowych pakietow Pythona). Dodaje:
- **automatyczny profil** (X11; na Waylandzie tylko dla programow przez XWayland) - wymaga `xprop`;
- **zegar** dla tarczy zegarka i statystyk Pomodoro;
- **Spotify**: tytul, wykonawca, postep (MPRIS: `playerctl` albo `gdbus`), okladka (ImageMagick albo ffmpeg).

## Instalacja
```
./install_linux.sh
```
Helper startuje od razu i sam po zalogowaniu (XDG autostart).
Dostep do portu DIAL: `sudo usermod -aG dialout $USER` (Arch: `uucp`), potem wyloguj sie i zaloguj.
Pakiety pomocnicze (Debian/Ubuntu): `sudo apt install x11-utils playerctl imagemagick`.

Odinstalowanie: `./install_linux.sh --uninstall`. Log: `~/.local/share/falbatech/dial-ft/helper.log`.
