#!/bin/bash
# DIAL FT Helper - instalacja na Linuksie (autostart po zalogowaniu, XDG autostart).
# Odinstalowanie: ./install_linux.sh --uninstall
set -e
DEST="$HOME/.local/share/falbatech/dial-ft"
DESKTOP="$HOME/.config/autostart/dial-ft-helper.desktop"
if [ "$1" = "--uninstall" ]; then
  [ -f "$DEST/dialft_helper.py" ] && python3 "$DEST/dialft_helper.py" --remove-claude-hooks 2>/dev/null || true
  [ -f "$DEST/dialft_helper.py" ] && python3 "$DEST/dialft_helper.py" --remove-codex-hooks 2>/dev/null || true
  pkill -f "$DEST/dialft_helper.py" 2>/dev/null || true
  rm -f "$DESKTOP"; rm -rf "$DEST"
  echo "DIAL FT Helper odinstalowany."; exit 0
fi
mkdir -p "$DEST" "$HOME/.config/autostart"
cp "$(dirname "$0")/dialft_helper.py" "$DEST/dialft_helper.py"
cat > "$DESKTOP" <<D
[Desktop Entry]
Type=Application
Name=DIAL FT Helper
Comment=FalbaTech DIAL FT: auto profile, clock, Spotify
Exec=sh -c 'python3 "$DEST/dialft_helper.py" >> "$DEST/helper.log" 2>&1'
X-GNOME-Autostart-enabled=true
NoDisplay=true
D
pkill -f "$DEST/dialft_helper.py" 2>/dev/null || true
nohup python3 "$DEST/dialft_helper.py" >> "$DEST/helper.log" 2>&1 &
# Claude Code: pytamy tylko, gdy jest zainstalowany (folder ~/.claude albo polecenie claude)
if [ -t 0 ] && { [ -d "$HOME/.claude" ] || command -v claude >/dev/null 2>&1; }; then
  read -r -p "Dodac powiadomienia Claude Code (DIAL pokaze, gdy Claude czeka na Ciebie)? [t/N] " ans || true
  case "$ans" in [tTyY]*) python3 "$DEST/dialft_helper.py" --install-claude-hooks ;; esac
fi
# Codex (OpenAI): pytamy tylko, gdy jest zainstalowany (folder ~/.codex albo polecenie codex)
if [ -t 0 ] && { [ -d "$HOME/.codex" ] || command -v codex >/dev/null 2>&1; }; then
  read -r -p "Dodac powiadomienia Codex (DIAL pokaze, gdy Codex czeka na Ciebie)? [t/N] " ans || true
  case "$ans" in [tTyY]*) python3 "$DEST/dialft_helper.py" --install-codex-hooks ;; esac
fi
echo "DIAL FT Helper zainstalowany i uruchomiony. Log: $DEST/helper.log"
if ! id -nG | grep -qwE "dialout|uucp"; then
  echo "UWAGA: aby helper widzial DIAL FT, dodaj sie do grupy portow szeregowych i zaloguj ponownie:"
  echo "  sudo usermod -aG dialout \$USER     (Arch: uucp zamiast dialout)"
fi
for t in xprop playerctl; do command -v $t >/dev/null || echo "Wskazowka: zainstaluj '$t' (auto-profil / Spotify)."; done
command -v magick >/dev/null || command -v convert >/dev/null || command -v ffmpeg >/dev/null || echo "Wskazowka: zainstaluj imagemagick albo ffmpeg (okladki Spotify)."
