#!/usr/bin/env python3
"""DIAL FT Helper (Linux) - automatyczny profil, zegar i Spotify Now Playing dla DIAL FT.

Tylko biblioteka standardowa Pythona 3 + narzedzia, ktore zwykle sa w systemie:
- program na wierzchu: xprop (X11). Na Waylandzie (np. GNOME) nie ma ogolnego sposobu - auto-profil wtedy nie dziala.
- Spotify: MPRIS przez playerctl albo gdbus (glib).
- okladka: ImageMagick (magick / convert) albo ffmpeg do zmniejszenia obrazka; bez nich tylko tytul i wykonawca.
Koniec Pomodoro / Timera / przypomnienie: DIAL wysyla "EVT <zdarzenie>" -> dzwiek (paplay / pw-play / canberra) i notify-send.
Wysyla na DIAL: "APP <proces>", "TIME <epoch> <strefa_min>", "NP META / NP OFF", okladke na zadanie "NP NEED <id>".

Uruchomienie: python3 dialft_helper.py   (autostart: install_linux.sh)
Dostep do portu: uzytkownik w grupie dialout (Debian/Ubuntu/Fedora) albo uucp (Arch).
"""
import base64
import socket
import glob
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import unicodedata
import urllib.request

VERSION = "1.2"
ART_W = ART_H = 112
CHUNK = 192


# ---------------------------------------------------------------- Claude Code (hooki http -> DIAL)
# Claude Code wysyla POST na http://127.0.0.1:47812/claude/<busy|ask|done|idle> (hooki typu "http" w ~/.claude/settings.json).
# Helper przekazuje "CLAUDE <STAN>" do DIAL i od razu odpowiada 200 bez tresci (Claude Code nic nie dostaje do kontekstu).
CLAUDE_PORT = 47812
CLAUDE_STATES = {"busy": "BUSY", "ask": "ASK", "done": "DONE", "idle": "IDLE"}
AI_AGENTS = ("claude", "codex")   # sciezka /<agent>/<stan> -> wiersz "<AGENT> <STAN>" do DIAL
CLAUDE_HOOKS = {"UserPromptSubmit": "busy", "Notification": "ask", "Stop": "done"}


def claude_server():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind(("127.0.0.1", CLAUDE_PORT))
    except OSError:
        log("port %d zajety - powiadomienia Claude Code wylaczone" % CLAUDE_PORT)
        return None
    s.listen(8)
    s.setblocking(False)
    return s


def claude_request(data):
    """Zwraca "AGENT STAN" z kompletnego zapytania HTTP albo None, gdy jeszcze nie doszlo w calosci ("" = obce)."""
    head, sep, body = data.partition(b"\r\n\r\n")
    if not sep:
        return None if len(data) < 16384 else ""
    length = 0
    for ln in head.split(b"\r\n")[1:]:
        k, _, v = ln.partition(b":")
        if k.strip().lower() == b"content-length":
            try:
                length = int(v.strip())
            except ValueError:
                pass
    if len(body) < min(length, 65536):
        return None
    parts = head.split(b"\r\n", 1)[0].decode(errors="ignore").split()
    path = parts[1] if len(parts) > 1 else ""
    seg = path.strip("/").split("/")
    if len(seg) != 2 or seg[0] not in AI_AGENTS or seg[1] not in CLAUDE_STATES:
        return ""
    return seg[0].upper() + " " + CLAUDE_STATES[seg[1]]


def claude_reply(c):
    try:
        c.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
    except OSError:
        pass
    c.close()


def claude_hooks(install):
    """Dodaje (albo usuwa) hooki DIAL FT w ~/.claude/settings.json; inne ustawienia i hooki zostaja."""
    import json
    path = os.path.expanduser("~/.claude/settings.json")
    try:
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
    except FileNotFoundError:
        cfg = {}
    except ValueError:
        sys.exit("Nie moge odczytac %s (bledny JSON) - nic nie zmieniono." % path)
    hooks = cfg.setdefault("hooks", {})
    mine = lambda h: str(h.get("url", "")).startswith("http://127.0.0.1:%d/claude/" % CLAUDE_PORT)
    for ev, st in CLAUDE_HOOKS.items():
        groups = [g for g in hooks.get(ev, []) if not any(mine(h) for h in g.get("hooks", []))]
        if install:
            groups.append({"hooks": [{"type": "http", "url": "http://127.0.0.1:%d/claude/%s" % (CLAUDE_PORT, st), "timeout": 3}]})
        if groups:
            hooks[ev] = groups
        else:
            hooks.pop(ev, None)
    if not hooks:
        cfg.pop("hooks")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f, open(path + ".dialft-backup", "w", encoding="utf-8") as b:
            b.write(f.read())
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print(("Dodano" if install else "Usunieto") + " powiadomienia DIAL FT w " + path)


CODEX_HOOKS = {"UserPromptSubmit": "busy", "PermissionRequest": "ask", "Stop": "done"}


def notify(agent, state):
    """Wywolywane przez hooki (np. Codex): przekazuje stan do dzialajacego Helpera; zawsze konczy sie po cichu."""
    try:
        sys.stdin.read() if not sys.stdin.isatty() else None   # hook podaje JSON na stdin - odczytujemy, zeby nie blokowac
    except Exception:
        pass
    try:
        c = socket.create_connection(("127.0.0.1", CLAUDE_PORT), 1)
        c.sendall(("POST /%s/%s HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Length: 0\r\nConnection: close\r\n\r\n" % (agent, state)).encode())
        c.settimeout(1)
        c.recv(64)
        c.close()
    except OSError:
        pass


def codex_hooks(install):
    """Dodaje (albo usuwa) hooki DIAL FT w ~/.codex/hooks.json; inne hooki zostaja."""
    import json
    path = os.path.expanduser("~/.codex/hooks.json")
    try:
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
    except FileNotFoundError:
        cfg = {}
    except ValueError:
        sys.exit("Nie moge odczytac %s (bledny JSON) - nic nie zmieniono." % path)
    hooks = cfg.setdefault("hooks", {})
    mine = lambda h: "dialft_helper" in str(h.get("command", "")) and "--notify codex" in str(h.get("command", ""))
    me = os.path.abspath(__file__)
    for ev, st in CODEX_HOOKS.items():
        groups = [g for g in hooks.get(ev, []) if not any(mine(h) for h in g.get("hooks", []))]
        if install:
            groups.append({"hooks": [{"type": "command", "command": '"%s" "%s" --notify codex %s' % (sys.executable, me, st), "timeout": 5}]})
        if groups:
            hooks[ev] = groups
        else:
            hooks.pop(ev, None)
    if not hooks:
        cfg.pop("hooks")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f, open(path + ".dialft-backup", "w", encoding="utf-8") as b:
            b.write(f.read())
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print(("Dodano" if install else "Usunieto") + " powiadomienia DIAL FT w " + path)
    if install:
        print("W Codex wpisz /hooks i zatwierdz nowe hooki (Codex uruchamia tylko zatwierdzone).")


def log(*a):
    print(time.strftime("%H:%M:%S"), "[DIAL FT]", *a, flush=True)


def run(cmd, timeout=2):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout
    except Exception:
        return ""


# ---------------------------------------------------------------- dzwiek i powiadomienie (EVT z DIAL)
# zdarzenie: (tekst PL, tekst EN, dzwiek freedesktop, ile razy zagrac)
ALERTS = {
    "POMO BREAK": ("Koniec skupienia - czas na przerwę", "Focus done - time for a break", "complete", 1),
    "POMO FOCUS": ("Koniec przerwy - wracamy do pracy", "Break over - back to work", "bell", 1),
    "TIMER": ("Czas minął", "Time's up", "alarm-clock-elapsed", 3),
    "STANDUP": ("Pora wstać i się rozruszać", "Time to stand up and stretch", "message", 1),    "CLAUDE ASK": ("Claude czeka na Ciebie", "Claude needs your input", "dialog-warning", 1),
    "CLAUDE DONE": ("Claude skończył", "Claude is done", "complete", 1),    "CODEX ASK": ("Codex czeka na Ciebie", "Codex needs your input", "dialog-warning", 1),
    "CODEX DONE": ("Codex skończył", "Codex is done", "complete", 1),
}
LANG_PL = (os.environ.get("LC_ALL") or os.environ.get("LC_MESSAGES") or os.environ.get("LANG") or "").startswith("pl")


def pc_alert(ev):
    a = ALERTS.get(ev)
    if not a:
        return
    text = a[0] if LANG_PL else a[1]
    snd = "/usr/share/sounds/freedesktop/stereo/%s.oga" % a[2]
    player = shutil.which("paplay") or shutil.which("pw-play")
    if player and os.path.exists(snd):
        cmd = 'for i in $(seq %d); do "%s" "%s"; done' % (a[3], player, snd)
    elif shutil.which("canberra-gtk-play"):
        cmd = 'for i in $(seq %d); do canberra-gtk-play -i "%s"; done' % (a[3], a[2])
    else:
        cmd = None
        sys.stdout.write("\a")
        sys.stdout.flush()
    if cmd:
        subprocess.Popen(["/bin/sh", "-c", cmd], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if shutil.which("notify-send"):
        subprocess.Popen(["notify-send", "-a", "DIAL FT", "DIAL FT", text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    log("powiadomienie:", text)


# ---------------------------------------------------------------- port szeregowy (termios)
class PosixSerial:
    def __init__(self, path):
        import termios
        import tty
        self.fd = os.open(path, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        tty.setraw(self.fd)
        attrs = termios.tcgetattr(self.fd)
        attrs[4] = attrs[5] = termios.B115200
        termios.tcsetattr(self.fd, termios.TCSANOW, attrs)
        self.name = path

    def read(self, n=4096):
        try:
            return os.read(self.fd, n)
        except BlockingIOError:
            return b""

    def write(self, data):
        view = memoryview(data)
        t0 = time.time()
        while view:
            try:
                k = os.write(self.fd, view)
                view = view[k:]
            except BlockingIOError:
                if time.time() - t0 > 2.0:
                    raise OSError("write timeout")
                time.sleep(0.002)

    def close(self):
        try:
            os.close(self.fd)
        except OSError:
            pass


def dial_ports():
    """Porty ttyACM z USB VID 303a (Espressif) - inne urzadzenia sa pomijane."""
    out = []
    for dev in sorted(glob.glob("/dev/ttyACM*")):
        sysdev = os.path.realpath("/sys/class/tty/%s/device" % os.path.basename(dev))
        for up in (sysdev, os.path.dirname(sysdev), os.path.dirname(os.path.dirname(sysdev))):
            try:
                if open(os.path.join(up, "idVendor")).read().strip().lower() == "303a":
                    out.append(dev)
                    break
            except OSError:
                continue
    return out


_warned_perm = False


def find_dial():
    global _warned_perm
    for path in dial_ports():
        try:
            s = PosixSerial(path)
        except PermissionError:
            if not _warned_perm:
                _warned_perm = True
                log("brak dostepu do %s: dodaj sie do grupy dialout (sudo usermod -aG dialout $USER) i zaloguj ponownie" % path)
            continue
        except OSError:
            continue
        try:
            s.write(b"HELLO\n")
            t0, buf = time.time(), b""
            while time.time() - t0 < 1.0:
                buf += s.read()
                if b"DIAL FT" in buf:
                    return s
                time.sleep(0.02)
        except OSError:
            pass
        s.close()
    return None


# ---------------------------------------------------------------- program na wierzchu (X11)
_have_xprop = shutil.which("xprop") is not None


def front_app():
    """Nazwa procesu okna na wierzchu, np. 'resolve', 'blender', 'spotify'."""
    if not _have_xprop or not os.environ.get("DISPLAY"):
        return ""
    m = re.search(r"window id # (0x[0-9a-fA-F]+)", run(["xprop", "-root", "_NET_ACTIVE_WINDOW"], 1))
    if not m or int(m.group(1), 16) == 0:
        return ""
    p = re.search(r"= (\d+)", run(["xprop", "-id", m.group(1), "_NET_WM_PID"], 1))
    if p:
        try:
            return open("/proc/%s/comm" % p.group(1)).read().strip()
        except OSError:
            pass
    c = re.search(r'WM_CLASS\(STRING\) = "([^"]*)"', run(["xprop", "-id", m.group(1), "WM_CLASS"], 1))
    return c.group(1) if c else ""


def time_line():
    now = time.time()
    return "TIME %d %d" % (int(now), int(round(time.localtime(now).tm_gmtoff / 60)))


# ---------------------------------------------------------------- Spotify (MPRIS)
def ascii_text(s, n=40):
    s = s.replace("ł", "l").replace("Ł", "L").replace("\t", " ")
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()[:n]


def spotify_now():
    """Zwraca slownik z danymi utworu albo None (Spotify nie dziala)."""
    if shutil.which("playerctl"):
        out = run(["playerctl", "-p", "spotify", "metadata", "--format",
                   "{{status}}\x1f{{position}}\x1f{{mpris:length}}\x1f{{mpris:trackid}}\x1f{{xesam:title}}\x1f{{xesam:artist}}\x1f{{mpris:artUrl}}"]).strip()
        p = out.split("\x1f")
        if len(p) >= 7 and p[0]:
            return _np(p[0] == "Playing", p[1], p[2], p[3], p[4], p[5], p[6])
        return None
    if shutil.which("gdbus"):
        base = ["gdbus", "call", "--session", "--dest", "org.mpris.MediaPlayer2.spotify",
                "--object-path", "/org/mpris/MediaPlayer2", "--method", "org.freedesktop.DBus.Properties.Get",
                "org.mpris.MediaPlayer2.Player"]
        md = run(base + ["Metadata"])
        if not md:
            return None
        status = run(base + ["PlaybackStatus"])
        pos = re.search(r"int64 (\d+)", run(base + ["Position"]))

        def g(key, pat=r"'([^']*)'"):
            m = re.search(r"'%s': <(?:\[)?%s" % (re.escape(key), pat), md)
            return m.group(1) if m else ""
        return _np("Playing" in status, pos.group(1) if pos else "0", g("mpris:length", r"(?:uint64|int64)? ?(\d+)"),
                   g("mpris:trackid", r"(?:objectpath )?'([^']*)'"), g("xesam:title"), g("xesam:artist"), g("mpris:artUrl"))
    return None


def _np(playing, pos_us, len_us, trackid, title, artist, art):
    def us(v):
        try:
            return int(float(v)) // 1000000
        except ValueError:
            return 0
    tid = (trackid.split(":")[-1].split("/")[-1] or hashlib.md5((title + artist).encode()).hexdigest())[:22]
    return {"playing": playing, "pos": us(pos_us), "dur": us(len_us), "id": tid,
            "title": ascii_text(title), "artist": ascii_text(artist), "art": art.replace("open.spotify.com/image", "i.scdn.co/image")}


_art_cache = {}


def artwork_rgb565(url):
    """Pobiera okladke i zmniejsza ja do 112x112 RGB (ImageMagick albo ffmpeg) -> RGB565 little endian."""
    if url in _art_cache:
        return _art_cache[url]
    if not url.startswith("http"):
        return None
    tool = shutil.which("magick") or shutil.which("convert")
    ff = shutil.which("ffmpeg")
    if not tool and not ff:
        return None
    tmp = tempfile.mkdtemp(prefix="dialft_")
    src = os.path.join(tmp, "a.img")
    try:
        with urllib.request.urlopen(url, timeout=5) as r, open(src, "wb") as f:
            f.write(r.read())
        if tool:
            raw = subprocess.run([tool, src, "-resize", "%dx%d!" % (ART_W, ART_H), "-depth", "8", "rgb:-"],
                                 capture_output=True, timeout=10).stdout
        else:
            raw = subprocess.run([ff, "-loglevel", "error", "-i", src, "-vf", "scale=%d:%d" % (ART_W, ART_H),
                                  "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True, timeout=10).stdout
        if len(raw) < ART_W * ART_H * 3:
            return None
        out = bytearray(ART_W * ART_H * 2)
        for i in range(ART_W * ART_H):
            r, g, b = raw[i * 3], raw[i * 3 + 1], raw[i * 3 + 2]
            v = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)
            out[i * 2] = v & 0xFF
            out[i * 2 + 1] = v >> 8
        _art_cache.clear()
        _art_cache[url] = bytes(out)
        return _art_cache[url]
    except Exception as e:
        log("okladka:", e)
        return None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------------------------------------------------------------- main
def main():
    log("DIAL FT Helper (Linux) %s" % VERSION)
    if not _have_xprop:
        log("brak xprop - automatyczny profil wylaczony (zainstaluj x11-utils / xorg-xprop)")
    elif os.environ.get("XDG_SESSION_TYPE") == "wayland":
        log("sesja Wayland - automatyczny profil dziala tylko dla programow przez XWayland")
    ser, buf = None, b""
    last_search = last_time = last_front = last_np = 0.0
    front, sent_off, np_ = "", False, None
    csrv, cclients = claude_server(), {}

    def send(line):
        nonlocal ser
        if not ser:
            return
        try:
            ser.write((line + "\n").encode())
        except OSError:
            log("DIAL FT odlaczony")
            ser.close()
            ser = None

    while True:
        now = time.time()
        if csrv:   # Claude Code: hooki http
            try:
                c, _ = csrv.accept()
                c.setblocking(False)
                cclients[c] = [b"", now]
            except (BlockingIOError, OSError):
                pass
            for c in list(cclients):
                try:
                    data = c.recv(65536)
                except BlockingIOError:
                    data = None
                except OSError:
                    data = b""
                if data:
                    cclients[c][0] += data
                st = claude_request(cclients[c][0])
                if st is None and data != b"" and now - cclients[c][1] < 3:
                    continue
                cclients.pop(c, None)
                claude_reply(c)
                if st:
                    send(st)
        if not ser and now - last_search > 2.0:
            last_search = now
            ser = find_dial()
            if ser:
                log("polaczono z DIAL FT:", ser.name)
                buf, last_time, front, sent_off = b"", 0.0, "", False
        if ser:
            try:
                data = ser.read()
            except OSError:
                data = None
            if data is None:
                log("DIAL FT odlaczony")
                ser.close()
                ser = None
                continue
            buf += data
            while b"\n" in buf:
                raw, buf = buf.split(b"\n", 1)
                line = raw.decode(errors="ignore").strip()
                if line.startswith("EVT "):
                    pc_alert(line[4:].strip())
                elif line.startswith("NP NEED ") and np_ and np_["id"] == line[8:].strip():
                    art = artwork_rgb565(np_["art"])
                    if art:
                        n = (len(art) + CHUNK - 1) // CHUNK
                        send("NP ART %s %d %d %d" % (np_["id"], ART_W, ART_H, n))
                        for i in range(n):
                            send("NP A %d %s" % (i, base64.b64encode(art[i * CHUNK:(i + 1) * CHUNK]).decode()))
                            if i % 8 == 7:
                                time.sleep(0.004)
                        send("NP END %s" % np_["id"])
            if now - last_time > 600:
                last_time = now
                send(time_line())
            if now - last_front > 0.8:
                last_front = now
                f = front_app()
                if f and f != front:
                    front = f
                    send("APP " + f)
            if now - last_np > 1.0:
                last_np = now
                np_ = spotify_now()
                if not np_:
                    if not sent_off:
                        send("NP OFF")
                        sent_off = True
                else:
                    sent_off = False
                    send("NP META %d %d %d %s\t%s\t%s" % (np_["playing"], np_["pos"], np_["dur"], np_["id"] or "-",
                                                          np_["title"], np_["artist"]))
        time.sleep(0.05)


if __name__ == "__main__" and len(sys.argv) > 1 and sys.argv[1] in ("--install-claude-hooks", "--remove-claude-hooks"):
    claude_hooks(sys.argv[1] == "--install-claude-hooks")
    sys.exit(0)
if __name__ == "__main__" and len(sys.argv) > 1 and sys.argv[1] in ("--install-codex-hooks", "--remove-codex-hooks"):
    codex_hooks(sys.argv[1] == "--install-codex-hooks")
    sys.exit(0)
if __name__ == "__main__" and len(sys.argv) > 3 and sys.argv[1] == "--notify":   # hook: --notify <claude|codex> <busy|ask|done|idle>
    notify(sys.argv[2], sys.argv[3])
    sys.exit(0)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
